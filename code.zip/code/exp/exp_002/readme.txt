This is Experiment 002 of the project. Same as 001....but adding 0.25 in pm values to show if someone moved to a new location with higher PM25
