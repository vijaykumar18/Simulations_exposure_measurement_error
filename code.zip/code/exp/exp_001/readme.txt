This is Experiment 001 of the project. It was created to to run baseline experiment.
