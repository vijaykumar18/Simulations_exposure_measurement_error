This is Experiment 003 of the project. Same as 001....but subtracting 0.25 in pm values to show if someone moved to a new location with lower PM25

